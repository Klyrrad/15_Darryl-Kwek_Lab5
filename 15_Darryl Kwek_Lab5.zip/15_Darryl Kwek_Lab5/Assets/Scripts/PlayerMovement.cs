﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{

    public float speed;
    public Rigidbody PlayerRigibody;
    public Text CoinCollectedText;
    int Coins;
    

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Coins = GameObject.FindGameObjectsWithTag("Coin").Length;
        CoinCollectedText.text = "Coins Left: " + Coins;
        
        if (Coins == 0)
        {
            SceneManager.LoadScene("GameWin");
        }

    }

    
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigibody.AddForce(movement * speed * Time.deltaTime);

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);

        }

        else if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}
